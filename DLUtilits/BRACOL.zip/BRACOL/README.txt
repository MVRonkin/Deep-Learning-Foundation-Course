roboflow:
  workspace: jonatan-fragoso
  project: bracol-original-detect
  version: 1
  license: CC BY 4.0
  url: https://universe.roboflow.com/jonatan-fragoso/bracol-original-detect/dataset/1

@misc{jonatan_rodrigues_borges_fragoso_cl_cio_elias_silva_e_silva_2025,
	title={BRACOL for YOLO Detection},
	url={https://www.kaggle.com/ds/6769488},
	DOI={10.34740/KAGGLE/DS/6769488},
	publisher={Kaggle},
	author={Jonatan Rodrigues Borges Fragoso and Clécio Elias Silva e Silva},
	year={2025}
	}

Original Dataset: https://doi.org/10.1016/j.compag.2019.105162

Original Paper: https://www.sciencedirect.com/science/article/pii/S0168169919313225?via%3Dihub